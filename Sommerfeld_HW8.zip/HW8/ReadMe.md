#ReadMe

This week's lesson was a bit challenging but ultimately it was fun. jQuery what is very easy for me to understand but learning the new rules was tough. Like you need a fadeOut function on document.ready if you want to have certain divs fade in. Example being my star text (The text that says awesome”) it wouldn’t fade in.  I added a fade out to the Dot Ready function and it worked.



I didn’t do an artwork piece I page that displayed movies. I used the .animate() function to animate the movie covers in a circle. With the .animate()  could change the opacity and move the cover over one. To safe time I just built a reseter function. That reset at the div tags back to their original place.  I faded I also used an if statement to reset a variable that would cycle through the array that I built. 