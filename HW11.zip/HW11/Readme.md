#Week 11

So this week wasn’t very tough. I think that was because of how the lesson was set up. I struggled through figuring out the lesson and when it came to the homework it wasn’t little to no struggling. When I read the Homework I knew I wanted to make snake. I watch some coding train videos on snake and had a good idea of how to build the game. My friend gave me an idea that I should build two player snake.

Some Issues I found
- One snake has a bug that goes through the other.
- Sometimes the food doesn’t appear.
- And sometimes the computer can’t hand two key presses at a time
